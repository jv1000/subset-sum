# Revision 8d

EVIDENCE — Jennifer authorized these edits to the 5 November 2026 revision 8c. This folder contains the revised paper, editable source, change record and an accompanying numerical verification snapshot. Original files outside this folder were not edited.

## Read first

- `Voitle_SubsetSum_certified-0.48758_2026-11-05_rev8d.pdf`: revised paper.
- `main.tex`: editable, self-contained LaTeX source for the paper.
- `CHANGELOG.md`: changes and their relationship to the follow-up review.
- `PENDING_BEFORE_RELEASE.md`: remaining publication/provenance inputs.
- `verification/ARTIFACT_GUIDE.md`: map from numerical claims to inputs, code and stored results.
- `RELEASE_MANIFEST.json`: SHA-256 inventory of the distributable files.

PROVED — The three formal algorithmic theorem statements and all frozen numerical inputs are unchanged from the reviewed source/candidates. The conditional assumptions remain explicit. The revised paper does not claim that [S], general k=1, or a global capacity ceiling has been proved.

## Build

EVIDENCE — The source uses standard LaTeX packages and an inline bibliography; no external figure files or BibTeX pass are needed. With an installed TeX distribution, run `pdflatex main.tex` twice (or use `latexmk -pdf main.tex`). The delivered PDF was compiled with portable Tectonic 0.17.0. Tectonic's engine differs from pdfLaTeX, so line and page breaks can differ when rebuilt with another engine.

EVIDENCE — The local working folder also contains the portable compiler, its cache, build logs and page renders. Those generated working files are excluded from the distributable ZIP. The ZIP includes the revised PDF/source and verification snapshot, not a TeX installation.

## Checks performed

PROVED — Document checks verify balanced LaTeX environments, resolved internal reference labels, identical theorem statements, and unchanged candidate inputs. The final TeX log contains no undefined-reference, missing-character, underfull-box or overfull-box warnings. The compiler emits a Fontconfig configuration notice, but uses its bundled Latin Modern fonts successfully; the PDF text and rendered mathematics were inspected.

EVIDENCE — Every page was inspected in rendered contact sheets, including the expanded Hall proof. The revised paper has 28 pages. No numerical optimizer, moment integral, historical flow sweep or 430-certificate rerun was performed during the editorial revision. Stored independent numerical results are from the earlier registered audit, with exact input equality checked.

NOT CHECKED — The public repository's current release and its historical experiment files have not been authenticated by this local revision. See the pending-items file before treating the ZIP as the complete historical research archive.
