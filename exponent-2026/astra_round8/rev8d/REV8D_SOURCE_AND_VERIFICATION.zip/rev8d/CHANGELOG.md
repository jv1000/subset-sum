# Revision 8c to 8d

EVIDENCE — This implements the follow-up review in `REV8C_REVIEW.md`. `source_rev8c.tex` preserves the input, `changes.diff` records the exact source diff, and `edit_log.json` records the scripted edits. Section and theorem numbering remain stable.

| Review item | Change |
|---|---|
| C1: counting-floor scope | Repeated the enumeration and class-count premises in summaries; separated exact fixed-gap arithmetic from empirical global capacity. |
| C2: experimental scope | Restricted fewer-block, colour-coding, estimator and SOR claims to the tested searches; removed the unsupported exact common-corner conclusion. |
| C3: definitions | Added the circle normalization, log-density formulas, coefficient ordering, certificate-row notation, uniform polynomial quantifiers for M', and imported ternary notation. Defined the amplitude log-partition function before using its derivative. |
| C4: Hall proof | Expanded the proof into aggregation, symmetric submodular cuts, internal allocations and residual cuts. Displayed the previously omitted capacity calculations. |
| C5: precision | Marked rounded moment displays as approximations and distinguished them from stored ball centers/radii. Used the safe 3.21 coefficient bound and treated derivative bounds separately. |
| C6: artifacts | Added a hashable local snapshot, corrected rho9 metadata, removed stale floating display metadata, and supplied a Section T copy with explicit epsilon0 cost slacks. An external release remains a publication task. |
| C7: local corrections | Corrected the guard typo, ledger scope for k=1, historical reading guide, and dependency wording. Replaced unsupported KKT-normalization language with an explicitly exploratory sensitivity interpretation. |
| Story and flow | Shortened the abstract, introductory repetition and reviewer narrative; consolidated methods; retained the early theorem and explicit Corollary D explanation; added a focused research agenda. |
| Bridge | Used: “Here we improve this approach and examine the limits of its current analysis.” |

PROVED — All three formal theorem statements are verbatim unchanged. All scalar and coefficient inputs in the frozen candidates are unchanged. Numerical field changes are confined to correcting certificate-format metadata and omitting stale optimizer display fields; the independent exact/interval results are supplied separately.

## Material withheld rather than guessed

EVIDENCE — The critical-type table was removed because its run identity and association with M1 versus M2 were unspecified. The previous table remains in `source_rev8c.tex` and the diff. It can be restored with reproducible provenance; no main theorem depends on it.

EVIDENCE — The unprovided minimax argument and exact common-corner assertion were replaced with defined, directly justified derivative identities and explicitly scoped empirical observations. The previous text remains in the source snapshot.

EVIDENCE — The “0.80 of the exponent” and KKT normalization interpretation was removed; the local sensitivity numbers remain labelled as floating exploratory evidence. Restoring a quantitative KKT claim needs the original normalization, method and stationarity residuals.

## Retained limitations

NOT CHECKED — The revision does not authenticate the public repository, re-run all historic experiments, prove the imported algorithmic lemmas, or resolve the open conjectures. These distinctions remain explicit in the paper and artifact guide.
