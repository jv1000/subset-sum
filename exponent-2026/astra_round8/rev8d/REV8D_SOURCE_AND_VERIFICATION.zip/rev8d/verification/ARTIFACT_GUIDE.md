# Revision-8d verification snapshot

EVIDENCE — This snapshot packages Astra's earlier own-code audit for the frozen points used in revision 8d. It is an independently checkable numerical supplement, not the complete historical experiment archive. `MANIFEST.json` hashes every included file except itself. Results were not recomputed merely for the editorial revision; input equality was checked.

## Claim-to-file map

| Claim | Exact input | Verifier | Stored result / explanation |
|---|---|---|---|
| Base threshold, scalar slacks and fixed-gap floor | `candidates/candidate_base.json` | `audit_numbers.py`, `interval_core.py` | `numbers.json`, `NUMERICAL_METHOD.md` |
| Base moments | same | `verify_moments.py --candidate base --n 4096` | `moments_base_4096.json` |
| K16 threshold/scalars and moments | `candidates/candidate_K16.json` | same scripts, `--candidate K16` | `numbers.json`, `moments_K16_4096.json` |
| Conditional ternary threshold/scalars and moments | `candidates/candidate_ternary.json` | same scripts, `--candidate ternary` | `numbers.json`, `moments_ternary_4096.json` |
| Exclusion of tau <= 0.484 in the specified sufficient budget | constants/formula in script and method note | `verify_blocking.py` | `blocking.json`, `NUMERICAL_METHOD.md` |
| Selected exact combinatorial examples/controls | instances in script | `check_combinatorics.py` | `combinatorics.json`, `MATHEMATICAL_NOTES.md` |
| Ternary alias step | frozen ternary parameters; [S] and cited Base/OpenAI premises | written argument | `SECTION_T_v3_rev8d.md`, paper Appendix A |

NOT CHECKED — The selected combinatorial controls are not a reproduction of the paper's entire flow or exhaustive-search inventory. The snapshot also does not contain the author's 430 historical certificates or all independent implementations mentioned in the verification ledger. Those are separate historical artifacts.

## Input conventions

PROVED — Candidate scalar strings and coefficient strings are exact decimal rationals. Arrays `rc` and `sc` each have the cosine coefficients for harmonics 1–16 followed by the sine coefficients for harmonics 1–16. They define r(x), s(x), and then f=2^r/mean(2^r), g=2^s/mean(2^s), with normalized circle measure and the correlation convention f(x+w)g(w).

PROVED — All numerical inputs match the supplied round-8 candidates. The corrected J=1 metadata is rho0: (p,0); bounded rho1–rho8: (q,0,0); rho9: (q,0). Stale `floating_T` and `floating_margins` display fields are omitted where present. The original JSON hashes therefore differ from the packaged files; this is a metadata change, not a new parameter point. Use the supplied exact/interval result files for derived quantities.

PROVED — Interval endpoints in the own-code results are decimal strings rounded outward from the interval endpoints. Analytic quadrature errors are retained as outward interval strings with positive upper endpoints, rather than underflowed scalar zeros. The rounding implementation and inner/outer error arguments are described in `NUMERICAL_METHOD.md` and the verifier source. These results trust the stated arithmetic libraries; they are not proof-assistant formalizations.

## Running the checks

EVIDENCE — The code uses Python 3 and mpmath interval arithmetic. From this folder run, sequentially:

```
python audit_numbers.py
python verify_moments.py --candidate base --n 4096
python verify_moments.py --candidate K16 --n 4096
python verify_moments.py --candidate ternary --n 4096
python verify_blocking.py
python check_combinatorics.py
```

EVIDENCE — The three moment commands are separate runs; do not launch them concurrently on Jennifer's shared laptop. The scripts write their results into this folder, so use a copy if preserving this frozen manifest. The only relocation edit to the earlier numerical source is the candidate directory in `audit_numbers.py`, now relative to this snapshot. Each mathematical rerun should be pre-registered under the project's rules.

## Section T provenance

EVIDENCE — `SECTION_T_v3_rev8d.md` preserves the supplied complete v3 argument and its historical provenance. Its EM/SP/SK parameter conditions now explicitly carry the epsilon0 slack used in T7, matching the revised paper. The frozen point already satisfies these stronger statements. The header explains why a historical original-candidate hash differs from the packaged JSON hash. Historical notebook/script references in the document refer to the broader research repository, not necessarily files in this limited snapshot.
