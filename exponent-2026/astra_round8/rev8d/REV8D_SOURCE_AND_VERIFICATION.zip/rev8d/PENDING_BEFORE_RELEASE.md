# What is still needed

EVIDENCE — The manuscript edits and a compiled, visually checked PDF are complete. No further information is needed to use or review this revision. The following are release/provenance items, not missing text edits.

## Before the final public release

1. **EVIDENCE — Choose/publish the immutable archive or repository release.** The local snapshot has hashes and accompanies this PDF. The final public release should include it and give readers a stable commit/tag/archive link for the broader experiment record. No upload or repository change was authorized or performed here.
2. **NOT CHECKED — Confirm the historical files in that release.** The 430-certificate data, full flow/sweep inventories, and C13–C17 optimizer records are not reproduced in this local numerical snapshot. If you want Astra to check their packaging, supply the exact release or the exact files. If older Base/K16 certificate exports remain public, check their directed decimal endpoints and nonzero analytic-error exports; the new snapshot uses the independently checked interval-string results instead.

## Only if you want removed details restored

- **NOT CHECKED — Critical-type table:** provide its frozen filter/parameter input, producing script and output, run identifier, and whether the displayed type maximizes M1 or M2. Give both tilts if making a claim about both.
- **NOT CHECKED — Quantitative KKT interpretation:** provide the normalized constraints and multiplier output, or the perturbation size and control if the numbers are finite differences, together with stationarity residuals.
- **NOT CHECKED — Stronger amplitude-tilt/minimax assertion:** provide the full argument and its boundary hypotheses. The revised text retains only the derivative identities and finite experimental observation.

EVIDENCE — None of those optional restorations is required for the main conditional certified result. A human expert review of the expanded Hall proof and inherited algorithmic dependencies remains desirable, but is not presented as a new approval requirement.
